<?php
interface Controller {
    public function GetRoutingTable();
}

?>